﻿using Data.Dto;
using Data.Implementation;
using Entity.Model.Context;
using Entity.Model.Security;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Interface
{
    public class UsuarioData : IUsuarioData
    {
        private readonly AplicationDbContext context;
        protected readonly IConfiguration configuration;

        public UsuarioData(AplicationDbContext context, IConfiguration configuration)
        {
            this.context = context;
            this.configuration = configuration;
        }

        public async Task Delete(int id)
        {
            var entity = await GetById(id);
            if (entity == null)
            {
                throw new Exception("Registro no encontrado");
            }
            entity.deleted_at = DateTime.Parse(DateTime.Today.ToString());
            context.users.Update(entity);
            await context.SaveChangesAsync();
        }

        public async Task<IEnumerable<DataSelectDto>> GetAllSelect()
        {
            var sql = @"SELECT 
                        Id,
                        UserName AS Nombre 
                    FROM 
                        Parametro.Users
                    WHERE DeletedAt IS NULL AND Estado = 1
                    ORDER BY Id ASC";
            return await context.QueryAsync<DataSelectDto>(sql);
        }

        public async Task<User> GetById(int id)
        {
            var sql = @"SELECT * FROM Parametro.Users WHERE Id = @Id ORDER BY Id ASC";
            return await context.QueryFirstOrDefaultAsync<User>(sql, new { Id = id });
        }

        
          public async Task<PagedListDto<UsuarioDto>> GetDataTable(QueryFilterDto filter)
            {
                int pageNumber = filter.PageNumber == 0 ? int.Parse(configuration["Pagination:DefaultPageNumber"]) : filter.PageNumber;
                int pageSize = filter.PageSize == 0 ? int.Parse(configuration["Pagination:DefaultPageSize"]) : filter.PageSize;

                var sql = @"SELECT
                            u.Id,
                            u.UserName,
                            u.created_at AS CreatedAt,
                            u.updated_at AS UpdatedAt,
                            u.state AS State,
                            CONCAT(p.FirstName, ' ', p.LastName) AS PersonFullName
                        FROM dbo.Users u
                            INNER JOIN dbo.Persons p ON u.PersonId = p.Id
                        WHERE u.deleted_at IS NULL AND
                            (UPPER(CONCAT(u.UserName, p.FirstName, p.LastName)) LIKE UPPER(CONCAT('%', @filter, '%')))
                        ORDER BY " + (filter.ColumnOrder ?? "u.Id") + " " + (filter.DirectionOrder ?? "asc");

                IEnumerable<UsuarioDto> items = await context.QueryAsync<UsuarioDto>(sql, new { filter.Filter });

                var pagedItems = PagedListDto<UsuarioDto>.Create(items, pageNumber, pageSize);

                return pagedItems;
            }

      
        public async Task<User> Save(User entity)
        {
            context.users.Add(entity);
            await context.SaveChangesAsync();
            return entity;
        }

        public async Task Update(User entity)
        {
            context.Entry(entity).State = EntityState.Modified;
            await context.SaveChangesAsync();
        }

        public async Task<User> GetByCode(int id)
        {
            return await context.users.AsNoTracking().Where(item => item.Id == id).FirstOrDefaultAsync();
        }
    }
}
