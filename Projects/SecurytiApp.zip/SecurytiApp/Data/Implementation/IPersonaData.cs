﻿using Data.Dto;
using Entity.Model.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Implementation
{
    public interface IPersonaData
    {
        Task Delete(int id);
        Task<IEnumerable<DataSelectDto>> GetAllSelect();
        Task<Persona> Save(Persona entity);
        Task Update(Persona entity);

        Task<Persona> GetById(int id);

        Task<PagedListDto<PersonaDto>> GetDataTable(QueryFilterDto filter);
    }
}
