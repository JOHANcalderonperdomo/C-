﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Model.Security
{
    public class Usuario_rol
    {
        public int Id { get; set; }
        public int usuario_id { get; set; }
        public int rol_id { get; set; }
        public Usuario usuario { get; set; }
        public Rol rol { get; set; }
    }
}
