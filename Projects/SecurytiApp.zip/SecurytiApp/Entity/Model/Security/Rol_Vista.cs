﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity.Model.Security
{
    public class Rol_Vista
    {
        public int Id { get; set; }
        public int rol_id { get; set; }
        public int vista_id { get; set; }
        public Rol rol { get; set; }
        public Vista vista { get; set; }
    }
}
